from FUNCS import *
Username = ""
Pass = ""
LoggedIn = False
chrome_path = 'C:/Program Files/Google/Chrome/Application/chrome.exe %s'
import webbrowser
from tkinter.messagebox import askyesno, askquestion

def Login(event=None):
    global LoggedIn
    with open("userandpasses.txt", "rb")as file:
        for line in file:
            spLine = line.split()
            _encusername = spLine[0]
            _enecpassword = spLine[1]
            _username = _encusername.decode("utf-8")
            _password = _enecpassword.decode("utf-8")
            if _username == Userent.get() and _password == Passent.get():
                LoggedIn = True
                MainApp.Loggedin()
    if Userent.get() == "admin" and Passent.get() == "admin":
        AdminApp.AdminView()



def Register():
    with open("userandpasses.txt", "a")as file:
        file.write("\n")
        file.write(Userent.get())
        file.write(" ")
        file.write(Passent.get())

class MainApp:
    def Loggedin():
        root.withdraw()
        bRegister.quit()
        bLogin.quit()
        Username = Userent.get()
        Passent.quit()
        Userent.quit()
        wloggedIn = tk.Toplevel(root)
        wloggedIn.title("Main")
        wloggedIn.geometry('400x350')
        lWelcomeMes = tk.Label(wloggedIn,text=f"Welcome {Username}")
        lWelcomeMes.pack()
        bOpenChrome = tk.Button(wloggedIn, text="Open Google Chrome", command=MainApp.openChrome)
        bOpenChrome.pack()
        entLink = tk.Entry(wloggedIn)
        entLink.pack()
        bOpenLink = tk.Button(wloggedIn, text="Open link in chrome", command=lambda : MainApp.openLink(entLink.get()))
        bOpenLink.pack()
        wloggedIn.protocol("WM_DELETE_WINDOW", MainApp.on_closing)
        wloggedIn.mainloop()

    def openLink(link):
        webbrowser.get(chrome_path).open(link)

    def openChrome():
        webbrowser.get(chrome_path).open("chrome://newtab")



    def on_closing():
        root.deiconify()  
        root.destroy()
        root.quit()



class AdminApp:
    import webbrowser
    from tkinter.messagebox import askyesno, askquestion
    def AdminView():
        root.withdraw()
        bRegister.quit()
        bLogin.quit()
        Passent.quit()
        Userent.quit()
        AdminView = tk.Toplevel(root)
        AdminView.title("Admin Panel")
        AdminView.geometry('400x350')
        bNormalwin = tk.Button(AdminView, text="Show Normal user view", command=AdminApp.ShowMain)
        bNormalwin.pack()
        bOpenCMD = tk.Button(AdminView, text="Open Command Prompt", command=AdminApp.OpenCMD)
        bOpenCMD.pack()
        bOpenUsers = tk.Button(AdminView, text="Open Users and Passwords list", command=AdminApp.openUserList)
        bOpenUsers.pack()
        bOpenSettings = tk.Button(AdminView, text="Open settings app", command=AdminApp.openSettings)
        bOpenSettings.pack()
        bLoginScreen = tk.Button(AdminView, text="UnHide the login screen", command=AdminApp.loginScreen)
        bLoginScreen.pack()
        AdminView.protocol("WM_DELETE_WINDOW", AdminApp.on_closing)
        AdminView.mainloop()


    def ShowMain():
        MainApp.Loggedin()
    
    def OpenCMD():
        os.system('start cmd.exe')

    def openUserList():
        editorread = askyesno(title="Read or edit", message="Press 'Yes' if you would like to open the file in edit mode")
        if editorread == False:
            webbrowser.open("file:///C:/Users/jacks/Desktop/VSCode%20Projects/LoginUi/userandpasses.txt")
        else:
            os.system("notepad 'C:/Users/jacks/Desktop/VSCode Projects/LoginUi/userandpasses.txt'")
    
    def openSettings():
        os.system("start ms-settings:")

    def loginScreen():
        root.deiconify()
    
    def on_closing():
        root.deiconify()  
        root.destroy()
        root.quit()








# mainloop, runs infinitely
root = tk.Tk()
  
# creating fixed geometry of the
# tkinter window with dimensions 150x200
root.geometry('200x150')
root.title("Login Field")
  
# Create Button and add some text
Userent = tk.Entry(root, textvariable=Username)
Userent.pack(side = tk.TOP, pady = 5)
Passent = tk.Entry(root, textvariable=Pass, show="*")
Passent.pack(side = tk.TOP, pady = 5)
bLogin = tk.Button(root, text="login", command=Login)
bLogin.pack()
bRegister = tk.Button(root, text="Register", command=Register)
bRegister.pack()

  

# Execute Tkinter
root.bind('<Return>', Login)
root.mainloop()
