import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import askyesno, askquestion
import os
import time
import webbrowser


def Repeat(command, index):
    Iterator = 0
    while Iterator != index:
        exec(command)


        